/**
 * ============================================================================
 * DAY DRAFT — FIREBASE CONFIGURATION
 * ============================================================================
 * This module initializes Firebase and exports the Auth instance plus the
 * OAuth providers used across the login flow. Every other script (auth.js,
 * dashboard guards, etc.) imports from this single source of truth so the
 * app is only ever initialized once.
 *
 * SETUP:
 * 1. Go to https://console.firebase.google.com and create a project.
 * 2. Enable Authentication > Sign-in method for:
 *      - Email/Password
 *      - Google
 *      - GitHub (requires a GitHub OAuth App Client ID/Secret)
 * 3. A Firebase project IS a Google Cloud project (same underlying
 *    project ID) — so go to https://console.cloud.google.com, select
 *    this same project, and enable the Gmail API and Google Calendar
 *    API under APIs & Services > Library. This lets the Google sign-in
 *    below also request Gmail/Calendar access in one flow.
 * 4. Copy your web app config from Project Settings > General > Your apps.
 * 5. Paste the values below.
 * 6. Add your production domain(s) to Authentication > Settings >
 *    Authorized domains.
 * ============================================================================
 */

// --- Firebase SDK imports (v10 modular, loaded via CDN in login.html) -------
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.2/firebase-app.js";
import {
  getAuth,
  GoogleAuthProvider,
  GithubAuthProvider,
  setPersistence,
  browserLocalPersistence,
  browserSessionPersistence,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

// --- 🔧 Replace with your own Firebase project credentials -----------------
const firebaseConfig = {
  apiKey: "AIzaSyAAGjdjtE9nuuosd9rdN4H7cE0mul50e8I",
  authDomain: "daydraft-ece00.firebaseapp.com",
  projectId: "daydraft-ece00",
  storageBucket: "daydraft-ece00.firebasestorage.app",
  messagingSenderId: "340983288519",
  appId: "1:340983288519:web:b26bc61367d153517924e2",
  measurementId: "G-C7CH2J1MDP",
};

// --- Initialize Firebase app + Auth service ---------------------------------
export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// --- OAuth providers ---------------------------------------------------------
// Google provider — requests basic profile + email scopes by default.
// We ALSO request Gmail (read-only) and Calendar (read-only) scopes here,
// so the SAME sign-in popup that logs the user in also grants Day Draft
// permission to read their inbox and calendar for extraction. This means
// there is only ONE Google OAuth flow in the whole app — login and Gmail/
// Calendar access happen together, not as two separate connections.
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: "select_account" });
googleProvider.addScope("https://www.googleapis.com/auth/gmail.readonly");
googleProvider.addScope("https://www.googleapis.com/auth/calendar.readonly");

// GitHub provider — requests read:user + user:email scopes by default.
export const githubProvider = new GithubAuthProvider();
githubProvider.addScope("read:user");

/**
 * Sets Firebase's session persistence based on the "Remember Me" checkbox.
 * - browserLocalPersistence: survives browser restarts (Remember Me = ON)
 * - browserSessionPersistence: cleared when the tab/browser closes (default)
 */
export async function applyPersistence(rememberMe) {
  const mode = rememberMe ? browserLocalPersistence : browserSessionPersistence;
  await setPersistence(auth, mode);
}
