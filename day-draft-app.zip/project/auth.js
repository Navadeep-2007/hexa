/**
 * ============================================================================
 * DAY DRAFT — AUTHENTICATION LOGIC
 * ============================================================================
 * Handles: form validation, Email/Password sign-in, Google OAuth,
 * GitHub OAuth, "Remember Me" persistence, loading states, success
 * animation, toast notifications, and the dashboard route guard.
 * ============================================================================
 */

import {
  signInWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  signOut,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-auth.js";

import { auth, googleProvider, githubProvider, applyPersistence } from "./firebase-config.js";

// ----------------------------------------------------------------------------
// DOM REFERENCES
// ----------------------------------------------------------------------------
const form = document.getElementById("login-form");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const rememberCheckbox = document.getElementById("remember-me");
const togglePasswordBtn = document.getElementById("toggle-password");
const loginBtn = document.getElementById("login-btn");
const loginBtnText = document.getElementById("login-btn-text");
const loginSpinner = document.getElementById("login-spinner");
const googleBtn = document.getElementById("google-signin");
const githubBtn = document.getElementById("github-signin");
const emailError = document.getElementById("email-error");
const passwordError = document.getElementById("password-error");
const toastContainer = document.getElementById("toast-container");
const successOverlay = document.getElementById("success-overlay");

const REDIRECT_URL = "dashboard.html";

// ----------------------------------------------------------------------------
// TOAST NOTIFICATIONS
// ----------------------------------------------------------------------------
/**
 * Renders a transient toast in the top-right corner.
 * @param {string} message
 * @param {"success"|"error"} type
 */
function showToast(message, type = "success") {
  const toast = document.createElement("div");
  const isSuccess = type === "success";

  toast.className = [
    "flex items-center gap-3 px-4 py-3 rounded-xl backdrop-blur-xl border shadow-lg",
    "font-inter text-sm text-slate-100 min-w-[260px] max-w-sm",
    "translate-x-[120%] opacity-0 transition-all duration-300 ease-out",
    isSuccess ? "bg-emerald-500/10 border-emerald-400/30" : "bg-rose-500/10 border-rose-400/30",
  ].join(" ");

  toast.innerHTML = `
    <span class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${
      isSuccess ? "bg-emerald-400/15 text-emerald-300" : "bg-rose-400/15 text-rose-300"
    }">
      ${
        isSuccess
          ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M5 13l4 4L19 7" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/></svg>'
          : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none"><path d="M12 9v4m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>'
      }
    </span>
    <span class="leading-snug">${message}</span>
  `;

  toastContainer.appendChild(toast);

  // Animate in on next frame
  requestAnimationFrame(() => {
    toast.classList.remove("translate-x-[120%]", "opacity-0");
  });

  // Auto-dismiss after 4.5s
  setTimeout(() => {
    toast.classList.add("translate-x-[120%]", "opacity-0");
    setTimeout(() => toast.remove(), 300);
  }, 4500);
}

// ----------------------------------------------------------------------------
// FIELD VALIDATION
// ----------------------------------------------------------------------------
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function setFieldError(input, errorEl, message) {
  errorEl.textContent = message;
  errorEl.classList.remove("hidden");
  input.classList.add("border-rose-400/60", "focus:ring-rose-400/40");
  input.classList.remove("border-white/10", "focus:ring-cyan-400/40");
  input.setAttribute("aria-invalid", "true");
}

function clearFieldError(input, errorEl) {
  errorEl.textContent = "";
  errorEl.classList.add("hidden");
  input.classList.remove("border-rose-400/60", "focus:ring-rose-400/40");
  input.classList.add("border-white/10", "focus:ring-cyan-400/40");
  input.setAttribute("aria-invalid", "false");
}

function validateEmail() {
  const value = emailInput.value.trim();
  if (!value) {
    setFieldError(emailInput, emailError, "Enter your email to continue.");
    return false;
  }
  if (!EMAIL_REGEX.test(value)) {
    setFieldError(emailInput, emailError, "Enter a valid email address.");
    return false;
  }
  clearFieldError(emailInput, emailError);
  return true;
}

function validatePassword() {
  const value = passwordInput.value;
  if (!value) {
    setFieldError(passwordInput, passwordError, "Enter your password to continue.");
    return false;
  }
  if (value.length < 6) {
    setFieldError(passwordInput, passwordError, "Password must be at least 6 characters.");
    return false;
  }
  clearFieldError(passwordInput, passwordError);
  return true;
}

// Live validation as the user types (clears errors as soon as they're fixed)
emailInput.addEventListener("input", () => {
  if (!emailError.classList.contains("hidden")) validateEmail();
});
passwordInput.addEventListener("input", () => {
  if (!passwordError.classList.contains("hidden")) validatePassword();
});

// ----------------------------------------------------------------------------
// SHOW / HIDE PASSWORD TOGGLE
// ----------------------------------------------------------------------------
const eyeOpenIcon = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.8"/></svg>`;
const eyeClosedIcon = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M17.94 17.94A10.94 10.94 0 0112 19c-7 0-11-7-11-7a20.3 20.3 0 015.06-5.94M9.9 4.24A10.5 10.5 0 0112 4c7 0 11 7 11 7a20.4 20.4 0 01-3.22 4.32M14.12 14.12a3 3 0 11-4.24-4.24" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/><path d="M1 1l22 22" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>`;

togglePasswordBtn.innerHTML = eyeOpenIcon;
togglePasswordBtn.addEventListener("click", () => {
  const isPassword = passwordInput.type === "password";
  passwordInput.type = isPassword ? "text" : "password";
  togglePasswordBtn.innerHTML = isPassword ? eyeClosedIcon : eyeOpenIcon;
  togglePasswordBtn.setAttribute(
    "aria-label",
    isPassword ? "Hide password" : "Show password"
  );
});

// ----------------------------------------------------------------------------
// LOADING / SUCCESS STATE HELPERS
// ----------------------------------------------------------------------------
function setLoading(isLoading) {
  loginBtn.disabled = isLoading;
  googleBtn.disabled = isLoading;
  githubBtn.disabled = isLoading;

  if (isLoading) {
    loginBtnText.textContent = "Signing in...";
    loginSpinner.classList.remove("hidden");
    loginBtn.classList.add("opacity-80", "cursor-not-allowed");
  } else {
    loginBtnText.textContent = "Sign In";
    loginSpinner.classList.add("hidden");
    loginBtn.classList.remove("opacity-80", "cursor-not-allowed");
  }
}

/** Plays the full-screen success animation, then redirects to the dashboard. */
function playSuccessAndRedirect() {
  successOverlay.classList.remove("hidden");
  requestAnimationFrame(() => {
    successOverlay.classList.remove("opacity-0");
    successOverlay.querySelector("#success-check").classList.add("scale-100", "opacity-100");
  });

  setTimeout(() => {
    window.location.href = REDIRECT_URL;
  }, 1400);
}

/** Maps raw Firebase error codes to friendly, actionable copy. */
function friendlyAuthError(code) {
  const map = {
    "auth/invalid-email": "That email address doesn't look right.",
    "auth/user-not-found": "No account matches that email.",
    "auth/wrong-password": "Incorrect password. Try again.",
    "auth/invalid-credential": "Email or password is incorrect.",
    "auth/too-many-requests": "Too many attempts. Wait a moment and try again.",
    "auth/popup-closed-by-user": "Sign-in window was closed before completing.",
    "auth/account-exists-with-different-credential":
      "An account already exists with a different sign-in method.",
    "auth/network-request-failed": "Network error. Check your connection and try again.",
  };
  return map[code] || "Something went wrong. Please try again.";
}

// ----------------------------------------------------------------------------
// EMAIL & PASSWORD SIGN-IN
// ----------------------------------------------------------------------------
form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const emailValid = validateEmail();
  const passwordValid = validatePassword();
  if (!emailValid || !passwordValid) return;

  setLoading(true);
  try {
    await applyPersistence(rememberCheckbox.checked);
    await signInWithEmailAndPassword(auth, emailInput.value.trim(), passwordInput.value);

    showToast("Signed in successfully. Redirecting…", "success");
    playSuccessAndRedirect();
  } catch (err) {
    showToast(friendlyAuthError(err.code), "error");
  } finally {
    setLoading(false);
  }
});

// ----------------------------------------------------------------------------
// GOOGLE OAUTH
// ----------------------------------------------------------------------------
// This one popup does DOUBLE DUTY: it logs the user into Day Draft AND
// grants Gmail/Calendar read access (scopes are set in firebase-config.js).
// The access token below is what the extraction step (Person 3's part)
// sends to the Gmail/Calendar APIs — no second OAuth flow needed.
googleBtn.addEventListener("click", async () => {
  setLoading(true);
  try {
    await applyPersistence(rememberCheckbox.checked);
    const result = await signInWithPopup(auth, googleProvider);

    // Extract the Google API access token from the sign-in result and
    // stash it for this session. The dashboard/backend reads this to
    // call Gmail and Calendar on the user's behalf.
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (credential?.accessToken) {
      sessionStorage.setItem("google_access_token", credential.accessToken);
    }

    showToast("Signed in with Google. Redirecting…", "success");
    playSuccessAndRedirect();
  } catch (err) {
    showToast(friendlyAuthError(err.code), "error");
  } finally {
    setLoading(false);
  }
});

// ----------------------------------------------------------------------------
// GITHUB OAUTH
// ----------------------------------------------------------------------------
githubBtn.addEventListener("click", async () => {
  setLoading(true);
  try {
    await applyPersistence(rememberCheckbox.checked);
    await signInWithPopup(auth, githubProvider);
    showToast("Signed in with GitHub. Redirecting…", "success");
    playSuccessAndRedirect();
  } catch (err) {
    showToast(friendlyAuthError(err.code), "error");
  } finally {
    setLoading(false);
  }
});

// ----------------------------------------------------------------------------
// KEYBOARD ACCESSIBILITY
// ----------------------------------------------------------------------------
// Allow "Enter" to submit from any field, and ensure OAuth buttons respond
// to both Enter and Space (native <button> already handles this, but we
// make sure focus rings are visible for keyboard users only).
document.addEventListener("keydown", (e) => {
  if (e.key === "Tab") document.body.classList.add("show-focus-rings");
});
document.addEventListener("mousedown", () => {
  document.body.classList.remove("show-focus-rings");
});

// ----------------------------------------------------------------------------
// ROUTE GUARD — call this at the top of dashboard.html
// ----------------------------------------------------------------------------
/**
 * Protects a page behind authentication. If no user is signed in, redirects
 * to login.html. Usage in dashboard.html:
 *
 *   import { requireAuth } from "./auth.js";
 *   requireAuth();
 */
export function requireAuth() {
  onAuthStateChanged(auth, (user) => {
    if (!user) {
      window.location.href = "login.html";
    }
  });
}

/** Signs the current user out and returns to the login screen. */
export async function logout() {
  await signOut(auth);
  window.location.href = "login.html";
}

// ----------------------------------------------------------------------------
// AUTO-REDIRECT IF ALREADY SIGNED IN
// ----------------------------------------------------------------------------
// If a returning user already has a valid session (Remember Me), skip the
// login form entirely and go straight to the dashboard.
onAuthStateChanged(auth, (user) => {
  if (user && window.location.pathname.endsWith("login.html")) {
    window.location.href = REDIRECT_URL;
  }
});
